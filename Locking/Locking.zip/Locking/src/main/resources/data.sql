-- Insert products with fixed IDs
INSERT INTO product (id, name, quantity, version) VALUES (1, 'Phone', 0, 0);
INSERT INTO product (id, name, quantity, version) VALUES (2, 'Laptop', 0, 0);

