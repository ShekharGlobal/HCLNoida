package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactiveR2DbcDemoApplication {
	
	public static void main(String[] args) {
		//TimeZone.setDefault(TimeZone.getDefault());
		SpringApplication.run(ReactiveR2DbcDemoApplication.class, args);
	}

}
