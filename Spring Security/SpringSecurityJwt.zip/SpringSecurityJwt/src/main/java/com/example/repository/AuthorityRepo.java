package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.MyGrantedAuthority;

public interface AuthorityRepo extends JpaRepository<MyGrantedAuthority,String> {

}
