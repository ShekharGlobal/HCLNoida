import React from 'react';
import PropTypes from 'prop-types';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import { Paper } from '@mui/material';

const DateDisplay = (() => (
  <Paper className="container">
      <List>
          <ListItem>
          <ListItemText data-testid="day">Day: </ListItemText>
      </ListItem>
      <ListItem>
          <ListItemText data-testid="month">Month: </ListItemText>
      </ListItem>
      <ListItem>
          <ListItemText data-testid="year">Year: </ListItemText>
      </ListItem>
      </List>
  </Paper>
));

DateDisplay.propTypes = {
  apiResponse: PropTypes.string
}

export default DateDisplay;