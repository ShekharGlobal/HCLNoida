package com.hcl.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.entity.Loan;

public interface LoanRepository extends JpaRepository<Loan, Long> {
	
	

}
